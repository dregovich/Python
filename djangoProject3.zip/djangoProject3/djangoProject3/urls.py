from django.urls import include, path
from django.contrib import admin

urlpatterns = [
    path('Admin/', admin.site.urls),
    path('info/', include('info.urls'))
]
