from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Title(models.Model):
    title_text = models.CharField(max_length=255)
    pub_date = models.DateTimeField('date published')

class New(models.Model):
    title = models.ForeignKey(Title, on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    correct = models.BooleanField(default=False)

class Message(models.Model):
    chat = models.ForeignKey(
        Title,
        verbose_name='Чат под загадкой',
        on_delete=models.CASCADE)
    author = models.ForeignKey(
        User,
        verbose_name='Пользователь', on_delete=models.CASCADE)
    message = models.TextField('Сообщение')
    pub_date = models.DateTimeField(
        'Дата сообщения',
        default=timezone.now)


class Mark(models.Model):
    title = models.ForeignKey(
        Title,
        verbose_name='Новость',
        on_delete=models.CASCADE,
        default=1)  # Здесь укажите значение по умолчанию
    author = models.ForeignKey(
        User,
        verbose_name='Пользователь', on_delete=models.CASCADE)
    mark = models.IntegerField(
        verbose_name='Оценка')
    pub_date = models.DateTimeField(
        'Дата оценки',
        default=timezone.now)


