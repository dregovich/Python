
from django.contrib import admin
from .models import Title
from .models import New
from .models import Message
from .models import Mark

admin.site.register(Title)
admin.site.register(New)
admin.site.register(Message)
admin.site.register(Mark)


